package cn.blockforge.generated.simpleminimap;

import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2902;
import net.minecraft.class_3620;
import net.minecraft.class_638;

final class ChunkColorSampler {
    private ChunkColorSampler() {
    }

    static void sampleAround(class_638 world, class_2338 center, ExplorationStore store) {
        int centerX = center.method_10263() >> 4;
        int centerZ = center.method_10260() >> 4;

        for (int offsetZ = -1; offsetZ <= 1; offsetZ++) {
            for (int offsetX = -1; offsetX <= 1; offsetX++) {
                int chunkX = centerX + offsetX;
                int chunkZ = centerZ + offsetZ;
                if (!world.method_8393(chunkX, chunkZ)) {
                    continue;
                }

                long key = class_1923.method_8331(chunkX, chunkZ);
                if (store.hasChunk(key)) {
                    continue;
                }

                class_2818 chunk = world.method_8497(chunkX, chunkZ);
                if (chunk == null) {
                    continue;
                }

                int[] colors = new int[256];
                for (int localZ = 0; localZ < 16; localZ++) {
                    for (int localX = 0; localX < 16; localX++) {
                        int worldX = (chunkX << 4) + localX;
                        int worldZ = (chunkZ << 4) + localZ;
                        int top = world.method_8624(class_2902.class_2903.field_13202, worldX, worldZ);

                        int surfaceY = Integer.MIN_VALUE;
                        class_2680 surface = null;
                        for (int depth = 0; depth < 16; depth++) {
                            int y = top - depth;
                            if (y < world.method_31607()) {
                                break;
                            }
                            class_2680 candidate = chunk.method_8320(new class_2338(worldX, y, worldZ));
                            if (!candidate.method_26215()) {
                                surface = candidate;
                                surfaceY = y;
                                break;
                            }
                        }

                        if (surface == null) {
                            continue;
                        }

                        class_2338 surfacePos = new class_2338(worldX, surfaceY, worldZ);
                        class_3620 mapColor = surface.method_26205(world, surfacePos);
                        if (mapColor == class_3620.field_16008) {
                            continue;
                        }

                        int rgb = mapColor.method_15820(class_3620.class_6594.field_34760) & 0x00ffffff;
                        colors[(localZ << 4) | localX] = 0xff000000 | rgb;
                    }
                }

                store.put(key, colors);
            }
        }
    }
}
