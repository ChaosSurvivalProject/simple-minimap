package cn.blockforge.generated.simpleminimap;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SuppressWarnings("deprecation")
public final class SimpleMinimapClient implements ClientModInitializer {
    public static final String MOD_ID = "simple_minimap";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static ClientWorldSession session;
    private static class_304 markerKey;

    @Override
    public void onInitializeClient() {
        session = new ClientWorldSession(class_310.method_1551());

        markerKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.simple_minimap.markers",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_M,
                class_304.class_11900.field_62556
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            session.tick();

            if (markerKey.method_1436()
                    && client.field_1755 == null
                    && session.isActive()
                    && client.field_1724 != null
                    && client.field_1687 != null) {
                client.method_1507(new MarkerScreen(session));
            }
        });

        // Fabric API 0.141.6+1.21.11 官方 Javadoc: HudRenderCallback 已弃用，
        // 但仍存在且签名为 (GuiGraphics, DeltaTracker) —— 在 Yarn build.6 中对应
        // (DrawContext, RenderTickCounter)。任务约束要求使用该回调，故保留；
        // 不使用 Mixin InGameHud，也不以 Screen.render 伪装 HUD。
        HudRenderCallback.EVENT.register((context, tickCounter) -> MinimapRenderer.render(context, session));

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> session.flush());
    }

    public static ClientWorldSession session() {
        return session;
    }
}
