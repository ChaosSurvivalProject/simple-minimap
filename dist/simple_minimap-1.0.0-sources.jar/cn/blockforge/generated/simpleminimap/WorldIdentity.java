package cn.blockforge.generated.simpleminimap;

import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import net.minecraft.class_310;
import net.minecraft.class_5218;
import net.minecraft.class_638;
import net.minecraft.class_642;
import net.minecraft.server.MinecraftServer;

public final class WorldIdentity {
    private WorldIdentity() {
    }

    public static String of(class_310 client, class_638 world) {
        String dimension = world.method_27983().method_29177().toString();
        String base = "unknown";

        MinecraftServer server = client.method_1576();
        if (server != null) {
            try {
                Path root = server.method_27050(class_5218.field_24188);
                Path name = root.getFileName();
                if (name != null) {
                    base = "singleplayer-" + name;
                }
            } catch (RuntimeException exception) {
                SimpleMinimapClient.LOGGER.warn("Could not read the integrated server save path", exception);
            }
        } else {
            class_642 info = client.method_1558();
            if (info != null && info.field_3761 != null && !info.field_3761.isBlank()) {
                base = "multiplayer-" + info.field_3761;
            }
        }

        String raw = base + "|" + dimension;
        String safe = raw.replaceAll("[^A-Za-z0-9._-]+", "_");
        if (safe.length() > 48) {
            safe = safe.substring(0, 48);
        }
        if (safe.isEmpty()) {
            safe = "world";
        }
        return safe + "-" + shortHash(raw);
    }

    private static String shortHash(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(value.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(hash).substring(0, 12);
        } catch (NoSuchAlgorithmException exception) {
            throw new IllegalStateException("SHA-256 is required by the Java runtime", exception);
        }
    }
}
