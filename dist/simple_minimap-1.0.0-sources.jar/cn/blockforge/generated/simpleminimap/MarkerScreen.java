package cn.blockforge.generated.simpleminimap;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class MarkerScreen extends class_437 {
    private final ClientWorldSession session;
    private final List<Marker> markers;
    private final class_2338 anchor;

    private class_342 nameField;
    private class_4185 previousButton;
    private class_4185 nextButton;
    private class_4185 renameButton;
    private class_4185 deleteButton;
    private int index;

    public MarkerScreen(ClientWorldSession session) {
        super(class_2561.method_43471("screen.simple_minimap.markers"));
        this.session = session;
        this.markers = new ArrayList<>(session.markers().snapshot());
        class_310 client = class_310.method_1551();
        this.anchor = client.field_1724 == null ? class_2338.field_10980 : client.field_1724.method_24515();
        this.index = 0;
    }

    @Override
    protected void method_25426() {
        int centerX = this.field_22789 / 2;

        this.nameField = new class_342(
                this.field_22793,
                centerX - 102,
                40,
                204,
                20,
                class_2561.method_43471("screen.simple_minimap.name")
        );
        this.nameField.method_1880(32);
        this.nameField.method_47404(class_2561.method_43471("screen.simple_minimap.name"));
        this.method_37063(this.nameField);
        this.method_48265(this.nameField);

        class_4185 addButton = class_4185.method_46430(
                        class_2561.method_43471("screen.simple_minimap.add"),
                        button -> addMarker()
                )
                .method_46433(centerX - 102, 66)
                .method_46432(204)
                .method_46431();
        this.method_37063(addButton);

        this.previousButton = class_4185.method_46430(
                        class_2561.method_43471("screen.simple_minimap.previous"),
                        button -> moveSelection(-1)
                )
                .method_46433(centerX - 102, 94)
                .method_46432(98)
                .method_46431();
        this.method_37063(this.previousButton);

        this.nextButton = class_4185.method_46430(
                        class_2561.method_43471("screen.simple_minimap.next"),
                        button -> moveSelection(1)
                )
                .method_46433(centerX + 4, 94)
                .method_46432(98)
                .method_46431();
        this.method_37063(this.nextButton);

        this.renameButton = class_4185.method_46430(
                        class_2561.method_43471("screen.simple_minimap.rename"),
                        button -> renameCurrent()
                )
                .method_46433(centerX - 102, 122)
                .method_46432(98)
                .method_46431();
        this.method_37063(this.renameButton);

        this.deleteButton = class_4185.method_46430(
                        class_2561.method_43471("screen.simple_minimap.delete"),
                        button -> deleteCurrent()
                )
                .method_46433(centerX + 4, 122)
                .method_46432(98)
                .method_46431();
        this.method_37063(this.deleteButton);

        if (!this.markers.isEmpty()) {
            this.nameField.method_1852(this.markers.get(this.index).name());
        }
        refreshButtons();
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);

        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 16, 0xffffffff);

        String currentName = this.markers.isEmpty()
                ? class_2561.method_43471("screen.simple_minimap.empty").getString()
                : this.markers.get(this.index).name();
        context.method_27534(
                this.field_22793,
                class_2561.method_43470(currentName),
                this.field_22789 / 2,
                154,
                0xffffffff
        );
    }

    @Override
    public void method_25432() {
        this.session.saveAsync();
    }

    private void addMarker() {
        String name = this.nameField.method_1882().trim();
        if (name.isEmpty()) {
            name = class_2561.method_43471("screen.simple_minimap.default").getString() + " " + (this.markers.size() + 1);
        }
        if (name.length() > 32) {
            name = name.substring(0, 32);
        }

        this.markers.add(new Marker(name, this.anchor.method_10263(), this.anchor.method_10264(), this.anchor.method_10260()));
        this.index = this.markers.size() - 1;
        this.nameField.method_1852(name);
        commit();
    }

    private void renameCurrent() {
        if (this.markers.isEmpty()) {
            return;
        }
        String name = this.nameField.method_1882().trim();
        if (name.isEmpty()) {
            name = this.markers.get(this.index).name();
        }
        if (name.length() > 32) {
            name = name.substring(0, 32);
        }

        Marker old = this.markers.get(this.index);
        this.markers.set(this.index, new Marker(name, old.x(), old.y(), old.z()));
        this.nameField.method_1852(name);
        commit();
    }

    private void deleteCurrent() {
        if (this.markers.isEmpty()) {
            return;
        }

        this.markers.remove(this.index);
        if (this.markers.isEmpty()) {
            this.index = 0;
            this.nameField.method_1852("");
        } else {
            this.index = Math.min(this.index, this.markers.size() - 1);
            this.nameField.method_1852(this.markers.get(this.index).name());
        }
        commit();
    }

    private void moveSelection(int direction) {
        if (this.markers.isEmpty()) {
            return;
        }
        this.index = Math.floorMod(this.index + direction, this.markers.size());
        this.nameField.method_1852(this.markers.get(this.index).name());
        refreshButtons();
    }

    private void commit() {
        this.session.markers().replaceAll(this.markers);
        this.session.saveAsync();
        refreshButtons();
    }

    private void refreshButtons() {
        boolean hasMarkers = !this.markers.isEmpty();
        this.previousButton.field_22763 = hasMarkers && this.markers.size() > 1;
        this.nextButton.field_22763 = hasMarkers && this.markers.size() > 1;
        this.renameButton.field_22763 = hasMarkers;
        this.deleteButton.field_22763 = hasMarkers;
    }
}
